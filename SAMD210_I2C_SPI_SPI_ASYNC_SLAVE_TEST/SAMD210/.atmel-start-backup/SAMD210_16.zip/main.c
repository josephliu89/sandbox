#include <atmel_start.h>
#include <hal_delay.h>
#include "dv_spi.h"

#define DV_EOL "\r\n"
#define DV_log(loglevel, fmt, ...) printf((loglevel fmt DV_EOL), ##__VA_ARGS__)
#define DV_info(fmt, ...) DV_log("[info]\t", fmt, ##__VA_ARGS__)
#define DV_warn(fmt, ...) DV_log("[warn]\t", fmt, ##__VA_ARGS__)
#define DV_error(fmt, ...) DV_log("[error]\t", fmt, ##__VA_ARGS__)

static uint8_t count = 0;

static void convert_cb_ADC_0(const struct adc_async_descriptor *const descr, const uint8_t channel)
{
    uint8_t buffer[2];
    uint16_t result = 0;

    adc_async_read_channel(&ADC_0, 0, buffer, 2);
    result = (buffer[1] << 8) | buffer[0];
    printf("ADC[%u]: %.2f\t", count, (3.3*result)/4095);
    if (++count == 3) {
        printf("\r\n");
        count = 0;
    }
}    

/*!
 * /brief   Blink green LED to indicate firmware isn't locked up
 */
static void TIMER_0_task1_cb(const struct timer_task *const timer_task) 
{
    gpio_toggle_pin_level(GLED_B);    
}    

static struct timer_task TIMER_0_task1;

/*!
 * /brief   Initialize 1 second timer
 */
static void initialize_TIMER_0(void) {
    TIMER_0_task1.interval = 1000;
    TIMER_0_task1.cb       = TIMER_0_task1_cb;
    TIMER_0_task1.mode     = TIMER_TASK_REPEAT;

    timer_add_task(&TIMER_0, &TIMER_0_task1);
}

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
    
    /* Initialize lock-up status timer */
    initialize_TIMER_0();    
    timer_start(&TIMER_0);
    
    /* Initialize SPI */
    initSpi();

    /* Initialize ADC */
    adc_async_register_callback(&ADC_0, 0, ADC_ASYNC_CONVERT_CB, convert_cb_ADC_0);
    adc_async_enable_channel(&ADC_0, 0);

    /* Note: Channel in this case means the number of ADC modules, not the number of ADC channels, that is why everything is
       referenced to "Channel" 0 and still works */
	while (1) {
        //gpio_toggle_pin_level(RLED_B);
        //gpio_toggle_pin_level(GLED_B);
        //if (count == 0) {
            //adc_async_set_inputs(&ADC_0, 0x00, 0x18, 0);
        //}
        //else if (count == 1) {
            //adc_async_set_inputs(&ADC_0, 0x01, 0x18, 0);            
        //}
        //else if (count == 2) {
            //adc_async_set_inputs(&ADC_0, 0x06, 0x18, 0);
        //}
        //adc_async_start_conversion(&ADC_0);
        //gpio_toggle_pin_level(RLED_B);    
        delay_ms(1000);
	}
}
