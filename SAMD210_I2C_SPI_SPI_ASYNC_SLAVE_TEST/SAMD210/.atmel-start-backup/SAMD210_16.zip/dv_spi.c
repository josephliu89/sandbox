#include <atmel_start.h>
#include "dv_spi.h"

static void complete_cb_SPI_0(const struct spi_s_async_descriptor *const desc) {
    /* Transfer completed */
    
}

static void tx_cb_SPI_0(const struct spi_s_async_descriptor *const desc) {
    /* Transfer completed */
    
}

static void rx_cb_SPI_0(const struct spi_s_async_descriptor *const desc) {
    /* Transfer completed */
    
}

void initSpi(void) {
        struct io_descriptor *io;
        spi_s_async_get_io_descriptor(&SPI_0, &io);
        spi_s_async_register_callback(&SPI_0, SPI_S_CB_TX, (FUNC_PTR)tx_cb_SPI_0);
        spi_s_async_register_callback(&SPI_0, SPI_S_CB_TX, (FUNC_PTR)complete_cb_SPI_0);
        spi_s_async_register_callback(&SPI_0, SPI_S_CB_RX, (FUNC_PTR)rx_cb_SPI_0);
        spi_s_async_enable(&SPI_0);
}