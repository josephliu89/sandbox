#include <atmel_start.h>
#include <hal_delay.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
    adc_sync_enable_channel(&ADC_0, 0);
    adc_sync_enable_channel(&ADC_0, 1);
    adc_sync_enable_channel(&ADC_0, 6);

	while (1) {
        gpio_toggle_pin_level(RLED_B);
        gpio_toggle_pin_level(GLED_B);

       	uint8_t buffer[2];

       	adc_sync_read_channel(&ADC_0, 1, buffer, 2);

        uint16_t result = 0;
        result = (buffer[1] << 8) | buffer[0];
        printf("ADC buffer[0]: 0x%X, buffer[1]: 0x%X\r\n", buffer[0], buffer[1]);        
        printf("ADC Result: %.2f\r\n", (3.3*result)/4095);

        delay_ms(1000);
	}
}
