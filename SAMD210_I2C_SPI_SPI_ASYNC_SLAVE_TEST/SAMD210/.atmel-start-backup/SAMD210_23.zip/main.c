#include <atmel_start.h>
#include <hal_delay.h>
#include "peripherals/dv_adc.h"
#include "peripherals/dv_spi.h"
#include "peripherals/dv_timer.h"
#include "driver_examples.h"

#define DV_EOL "\r\n"
#define DV_log(loglevel, fmt, ...) printf((loglevel fmt DV_EOL), ##__VA_ARGS__)
#define DV_info(fmt, ...) DV_log("[info]\t", fmt, ##__VA_ARGS__)
#define DV_warn(fmt, ...) DV_log("[warn]\t", fmt, ##__VA_ARGS__)
#define DV_error(fmt, ...) DV_log("[error]\t", fmt, ##__VA_ARGS__)

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
    
    /* Initialize timer to blink green status LED every second */
    initTimer();
    
    /* Initialize SPI */
    initSpi();
    
    /* Initialize ADC */
    initAdc();    

	while (1) { 
        printRxTxCount();
        processData();
        delay_ms(3000);
	}
}
