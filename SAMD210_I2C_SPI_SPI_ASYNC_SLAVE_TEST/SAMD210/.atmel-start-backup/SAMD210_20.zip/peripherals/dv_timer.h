#ifndef _DV_TIMER_INCLUDED
#define _DV_TIMER_INCLUDED

void initTimer(void);

#endif // _DV_TIMER_INCLUDED