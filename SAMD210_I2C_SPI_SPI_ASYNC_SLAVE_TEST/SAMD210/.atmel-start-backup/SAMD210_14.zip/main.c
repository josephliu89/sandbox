#include <atmel_start.h>
#include <hal_delay.h>

static void convert_cb_ADC_0(const struct adc_async_descriptor *const descr, const uint8_t channel)
{
    uint8_t buffer[14];
    uint16_t result = 0;

    adc_async_read_channel(&ADC_0, 0, buffer, 14);

    for (uint8_t i = 0; i++; i < 7)
    {
        result = (buffer[2*i+1] << 8) | buffer[2*i];
        printf("ADC CH[%i]: %lu\r\n", i, result);

    }
    
    //printf("ADC buffer[0]: 0x%X, buffer[1]: 0x%X\r\n", buffer[0], buffer[1]);
    //printf("ADC Result: %.2f\r\n", (3.3*result)/4095);
}

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */

    	adc_async_register_callback(&ADC_0, 0, ADC_ASYNC_CONVERT_CB, convert_cb_ADC_0);
    	adc_async_enable_channel(&ADC_0, 0);
        adc_async_enable_channel(&ADC_0, 1);
        adc_async_enable_channel(&ADC_0, 2);
        adc_async_enable_channel(&ADC_0, 3);
        adc_async_enable_channel(&ADC_0, 4);
        adc_async_enable_channel(&ADC_0, 5);
        adc_async_enable_channel(&ADC_0, 6);
    	adc_async_start_conversion(&ADC_0);

	while (1) {
        gpio_toggle_pin_level(RLED_B);
        gpio_toggle_pin_level(GLED_B);
        adc_async_start_conversion(&ADC_0);
        delay_ms(1000);
	}
}
