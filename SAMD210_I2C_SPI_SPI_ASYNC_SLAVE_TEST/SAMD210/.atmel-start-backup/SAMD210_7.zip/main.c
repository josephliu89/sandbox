#include <atmel_start.h>
#include <hal_delay.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	while (1) {
        gpio_toggle_pin_level(RLED_B);
        gpio_toggle_pin_level(GLED_B);

       	uint8_t buffer[2];

       	adc_sync_enable_channel(&ADC_0, 0);
       	adc_sync_read_channel(&ADC_0, 0, buffer, 2);

        printf("Buffer[0]: 0x%X\tBuffer[1]: 0x%X\r\n", buffer[0], buffer[1]);

        delay_ms(1000);
	}
}
