#include <atmel_start.h>
#include <hal_delay.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	while (1) {
        printf("Hi\r\n");
        gpio_toggle_pin_level(RLED_B);
        gpio_toggle_pin_level(GLED_B);
        delay_ms(1000);
	}
}
