#include <atmel_start.h>
#include "dv_spi.h"

void initSpi(void) {
	struct io_descriptor *io;
	spi_s_sync_get_io_descriptor(&SPI_0, &io);
	spi_s_sync_enable(&SPI_0);
}