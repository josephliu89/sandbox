#ifndef _DV_SPI_INCLUDED
#define _DV_SPI_INCLUDED

void initSpi(void);

#endif // _DV_SPI_INCLUDED