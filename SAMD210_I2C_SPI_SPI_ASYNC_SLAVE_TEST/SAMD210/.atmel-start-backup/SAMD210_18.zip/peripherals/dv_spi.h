#ifndef _DV_SPI_INCLUDED
#define _DV_SPI_INCLUDED

#define FRAME_BYTE (0x7E)
#define FRAME_ESCAPE_BYTE (0x7D)
#define FRAME_INVERT_MASK (0x10)

#pragma  pack(1)

typedef struct {
    uint8_t header;
    uint8_t devAddr;
    uint8_t regAddr;
    uint8_t data[2];
} commPacket;

void initSpi(void);
bool processData(void);

#endif // _DV_SPI_INCLUDED