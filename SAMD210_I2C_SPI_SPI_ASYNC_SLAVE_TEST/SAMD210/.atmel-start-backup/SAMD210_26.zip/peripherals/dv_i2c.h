#ifndef _DV_I2C_INCLUDED
#define _DV_I2C_INCLUDED

void initI2c(void);

#endif // _DV_I2C_INCLUDED